package com.example.provatrimestral11901322.Classes

class Product (
    var Name: String = "",
    var Description: String = "",
    var Value: Double = 0.0
)
